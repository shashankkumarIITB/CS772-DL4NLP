from assign1 import *




if __name__ == "__main__":
    val=main("train.csv","test.csv")
    print(val)